README
Overview
This dataset was created to support experiments on blockchain attack detection. Raw logs from simulated blockchain environments were parsed into structured CSV datasets using the pipeline_unified.py pipeline.
Files Included
      �	blockchain_logs2.txt:  Raw log for Dataset A.
      �	blockchain_logs3.txt:  Raw log for Dataset B.
      �	Dataset_A.csv:  Processed structured Dataset A.
      �	Dataset_B.csv:  Processed structured Dataset B.
      �	otheranalysis.py:  Python pipeline for parsing, feature extraction, ML, and evaluation.
      �	Jupyter notebooks (InitialMLanalysis.ipynb, Raw Simulation.ipynb):  Supplementary exploratory analyses.
How to Reproduce
Ensure Python =3.10 with required libraries:
      �	pip install numpy pandas scikit-learn imbalanced-learn matplotlib
      �	python .\pipeline_unified.py --dataA .\blockchain_logs2.txt --dataB .\blockchain_logs3.txt --outdir .\results --sampler smote
Outputs generated in .\results\:
      �	Structured datasets (CSV)
      �	Cross-validation metrics
      �	Per-attack evaluation
      �	Summary tables and plots
Data Processing Notes
      �	SMOTE was used to balance classes where specified.
      �	Each log line is parsed into an event row with engineered features.
      �	Binary attack labels assigned for supervised ML tasks.
Usage
These datasets can be used for:
      �	Blockchain security research.
      �	Machine learning attack detection experiments.
      �	Reproducibility of published results.

