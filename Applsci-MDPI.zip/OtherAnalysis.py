import argparse, time, math, joblib, tracemalloc, json, sys, platform
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Dict, Any, List, Tuple, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import StratifiedKFold, ParameterGrid
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, average_precision_score)
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, IsolationForest
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import OneClassSVM
from scipy.stats import ttest_rel, wilcoxon, t as t_dist

try:
    from imblearn.over_sampling import SMOTE, ADASYN
    HAS_IMB = True
except Exception:
    SMOTE = None
    ADASYN = None
    HAS_IMB = False

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    HAS_TORCH = True
except Exception:
    HAS_TORCH = False

RESULTS_DIR = Path("./results")
ARTIFACTS_DIR = Path("./results/artifacts")

@dataclass
class TimingRecord:
    t_feature_extract: float = math.nan
    t_preprocess: float = math.nan
    t_fit: float = math.nan
    t_predict: float = math.nan
    mem_peak_mb: float = math.nan
    model_size_mb: float = math.nan

def ensure_dirs(base: Path):
    (base).mkdir(parents=True, exist_ok=True)
    (base / "artifacts").mkdir(parents=True, exist_ok=True)

def save_json(obj: Dict[str, Any], path: Path):
    path.write_text(json.dumps(obj, indent=2))

def version_meta():
    meta = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
    }
    try:
        import sklearn, numpy, pandas
        meta.update({
            "sklearn": sklearn.__version__,
            "numpy": numpy.__version__,
            "pandas": pandas.__version__,
            "imbalanced_learn": None if not HAS_IMB else __import__("imblearn").__version__,
            "torch": None if not HAS_TORCH else torch.__version__,
        })
    except Exception:
        pass
    return meta

def parse_blockchain_logs(log_path: Path) -> pd.DataFrame:
    events = []
    with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
        lines = [ln.strip() for ln in f.readlines() if ln.strip()]

    for ln in lines:
        if ln.startswith("Node with hash rate "):
            
            try:
                hr = int(ln.split("Node with hash rate ")[1].split(" ")[0])
                events.append({"event":"add_node","hash_rate":hr,"blocks_before":0.0,"blocks_after":0.0,
                               "tx_added":0.0,"doc_flag":0.0,"nodes_count":0.0,"attack_type":"none","label_attack":0})
            except Exception: pass

        elif ln.startswith("Hash rate attack simulation:"):
            pass

        elif ln.startswith("Blockchain Length:"):
            
            try:
                length = int(ln.split(":")[1].strip())
                events.append({"event":"blockchain_len","hash_rate":0.0,"blocks_before":float(length),
                               "blocks_after":float(length),"tx_added":0.0,"doc_flag":0.0,"nodes_count":0.0,
                               "attack_type":"Hashrate","label_attack":1})
            except Exception: pass

        elif ln.startswith("Smart contract audit simulation:"):
            pass

        elif ln.startswith("Transaction ") and "added:" in ln:
            
            try:
                val = ln.split(":")[1].strip().lower()
                tx_added = 1 if val == "true" else 0
                events.append({"event":"tx_added","hash_rate":0.0,"blocks_before":0.0,"blocks_after":0.0,
                               "tx_added":float(tx_added),"doc_flag":0.0,"nodes_count":0.0,
                               "attack_type":"SmartContract","label_attack":int(tx_added == 0)})
            except Exception: pass

        elif "DoC Attack Identified" in ln:
            events.append({"event":"doc_flag","hash_rate":0.0,"blocks_before":0.0,"blocks_after":0.0,
                           "tx_added":0.0,"doc_flag":1.0,"nodes_count":0.0,"attack_type":"DoC","label_attack":1})

        elif ln.startswith("Number of Nodes after Sybil Attack:"):
            try:
                cnt = int(ln.split(":")[1].strip())
                events.append({"event":"sybil_nodes","hash_rate":0.0,"blocks_before":0.0,"blocks_after":0.0,
                               "tx_added":0.0,"doc_flag":0.0,"nodes_count":float(cnt),"attack_type":"Sybil","label_attack":1})
            except Exception: pass

        elif ln.startswith("Number of Nodes after Eclipse Attack:"):
            try:
                cnt = int(ln.split(":")[1].strip())
                events.append({"event":"eclipse_nodes","hash_rate":0.0,"blocks_before":0.0,"blocks_after":0.0,
                               "tx_added":0.0,"doc_flag":0.0,"nodes_count":float(cnt),"attack_type":"Eclipse","label_attack":1})
            except Exception: pass

        elif ln.startswith("Finney Attack Simulation:"):
            pass

        elif ln.startswith("Block added:"):
            try:
                val = ln.split(":")[1].strip().lower()
                added = 1 if val == "true" else 0
                events.append({"event":"finney_block_added","hash_rate":0.0,"blocks_before":0.0,"blocks_after":0.0,
                               "tx_added":0.0,"doc_flag":0.0,"nodes_count":0.0,"attack_type":"Finney","label_attack":int(added == 0)})
            except Exception: pass

    df = pd.DataFrame(events)
    for col in ["hash_rate","blocks_before","blocks_after","tx_added","doc_flag","nodes_count"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0.0)
    df["blocks_delta"] = (df.get("blocks_after",0.0) - df.get("blocks_before",0.0)).fillna(0.0)
    if "label_attack" not in df.columns: df["label_attack"] = 0
    if "attack_type" not in df.columns:  df["attack_type"] = "none"
    return df

def build_feature_label(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series, pd.Series]:
    feats = ["hash_rate","blocks_before","blocks_after","blocks_delta","tx_added","doc_flag","nodes_count"]
    X = df[feats].copy()
    y = df["label_attack"].astype(int).copy()
    atk = df["attack_type"].astype(str).copy()
    return X, y, atk

def make_models(random_state: int = 0) -> Dict[str, Any]:
    models = {
        "logreg":  LogisticRegression(penalty="l2", C=1.0, solver="lbfgs", max_iter=200, random_state=random_state),
        "rf":      RandomForestClassifier(n_estimators=200, max_depth=10, criterion="gini", random_state=random_state, n_jobs=-1),
        "gb":      GradientBoostingClassifier(n_estimators=150, learning_rate=0.05, max_depth=3, random_state=random_state),
        "knn":     KNeighborsClassifier(n_neighbors=5, weights="uniform", algorithm="auto"),
        "ocsvm":   OneClassSVM(kernel="rbf", nu=0.5, gamma="scale"),
        "iforest": IsolationForest(n_estimators=200, max_samples="auto", contamination=0.1, random_state=random_state),
    }
    if HAS_TORCH:
        class AE(nn.Module):
            def __init__(self, in_dim):
                super().__init__()
                self.encoder = nn.Sequential(
                    nn.Linear(in_dim,64), nn.ReLU(),
                    nn.Linear(64,32), nn.ReLU(),
                    nn.Linear(32,16), nn.ReLU()
                )
                self.decoder = nn.Sequential(
                    nn.Linear(16,32), nn.ReLU(),
                    nn.Linear(32,64), nn.ReLU(),
                    nn.Linear(64,in_dim)
                )
            def forward(self, x): return self.decoder(self.encoder(x))
        models["autoencoder"] = ("autoencoder", AE)
    return models

def serialize_model(path: Path, model) -> float:
    joblib.dump(model, path)
    return path.stat().st_size / (1024*1024)

def _metric_dict(y_true, y_pred, y_scores=None) -> Dict[str,float]:
    out = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "anomaly_rate": float(np.mean(y_pred)),
    }
    try:
        if y_scores is not None and len(np.unique(y_true)) == 2:
            out["roc_auc"] = roc_auc_score(y_true, y_scores)
            out["pr_auc"]  = average_precision_score(y_true, y_scores)
    except Exception:
        pass
    return out

def _auto_n_splits(y, desired=10):
    vals, counts = np.unique(np.asarray(y), return_counts=True)
    min_class = counts.min() if counts.size > 0 else 0
    return max(2, min(desired, int(min_class)))

def fit_predict_model(name: str, model, X_tr_raw, y_tr, X_te_raw, setup: str, scaler: Optional[StandardScaler], seed: int, artifacts_dir: Path) -> Tuple[np.ndarray, Optional[np.ndarray], TimingRecord, Any]:
    t_rec = TimingRecord()
    tracemalloc.start()

    _t = time.perf_counter()
    if scaler is not None:
        scaler.fit(X_tr_raw)
        X_tr = scaler.transform(X_tr_raw)
        X_te = scaler.transform(X_te_raw)
    else:
        X_tr, X_te = X_tr_raw, X_te_raw
    t_rec.t_preprocess = time.perf_counter() - _t

    _t = time.perf_counter()
    fitted = None
    if name in ("ocsvm","iforest"):
        fitted = model.fit(X_tr)
    elif name == "autoencoder" and model is not None and HAS_TORCH:
        label, AE = model
        in_dim = X_tr.shape[1]
        net = AE(in_dim)
        opt = optim.Adam(net.parameters(), lr=1e-3)
        loss_fn = nn.MSELoss()
        Xtr_t = torch.tensor(X_tr, dtype=torch.float32)
        net.train()
        for _ in range(30):
            opt.zero_grad(); out = net(Xtr_t); loss = loss_fn(out, Xtr_t); loss.backward(); opt.step()
        fitted = net
    else:
        fitted = model.fit(X_tr, y_tr)
    t_rec.t_fit = time.perf_counter() - _t

    _t = time.perf_counter()
    if name in ("ocsvm","iforest"):
        y_scores = fitted.decision_function(X_te)  
        y_pred = (fitted.predict(X_te) == -1).astype(int)  
    elif name == "autoencoder" and model is not None and HAS_TORCH:
        fitted.eval(); Xte_t = torch.tensor(X_te, dtype=torch.float32)
        with torch.no_grad(): recon = fitted(Xte_t).numpy()
        err = np.mean((recon - X_te)**2, axis=1)
        med = np.median(err); mad = np.median(np.abs(err-med)) + 1e-8
        thr = med + 3*mad
        y_pred = (err >= thr).astype(int); y_scores = err
    else:
        y_scores = fitted.predict_proba(X_te)[:,1] if hasattr(fitted,"predict_proba") else None
        y_pred = fitted.predict(X_te)
    t_rec.t_predict = time.perf_counter() - _t

    _, peak = tracemalloc.get_traced_memory(); tracemalloc.stop()
    t_rec.mem_peak_mb = peak/(1024*1024)
    try:
        t_rec.model_size_mb = serialize_model(artifacts_dir / f"{name}_{setup}_seed{seed}.joblib", fitted)
    except Exception:
        t_rec.model_size_mb = math.nan

    return y_pred, y_scores, t_rec, fitted



def crossval_with_per_attack(X, y, atk, setup: str, seeds: List[int], sampler: str, results_dir: Path) -> pd.DataFrame:
    rows, per_attack_rows = [], []
    artifacts_dir = results_dir / "artifacts"

    for seed in seeds:
        n_splits = _auto_n_splits(y, 10)
        if n_splits < 2:
            raise ValueError(f"Not enough samples per class for CV. Class counts: {np.bincount(y)}")
        skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)

        for fold, (tr_idx, te_idx) in enumerate(skf.split(X, y), start=1):
            X_tr, X_te = X.iloc[tr_idx], X.iloc[te_idx]
            y_tr, y_te = y.iloc[tr_idx], y.iloc[te_idx]
            atk_te = atk.iloc[te_idx]

            
            if sampler in ("smote","adasyn") and HAS_IMB:
                resampler = SMOTE(random_state=seed) if sampler == "smote" else ADASYN(random_state=seed)
                X_tr, y_tr = resampler.fit_resample(X_tr, y_tr)

            scaler = StandardScaler()
            base_models = make_models(random_state=seed)

            for name, mdl in base_models.items():
                
                if name == "knn":
                    n_train = X_tr.shape[0]
                    k = min(5, max(1, n_train))
                    mdl = KNeighborsClassifier(n_neighbors=k, weights="uniform", algorithm="auto")
                if name == "autoencoder" and not HAS_TORCH:
                    continue

                if name == "logreg":
                    mdl = LogisticRegression(penalty="l2", C=1.0, solver="lbfgs", max_iter=200, random_state=seed)
                elif name == "rf":
                    mdl = RandomForestClassifier(n_estimators=200, max_depth=10, criterion="gini", random_state=seed, n_jobs=-1)
                elif name == "gb":
                    mdl = GradientBoostingClassifier(n_estimators=150, learning_rate=0.05, max_depth=3, random_state=seed)
                elif name == "ocsvm":
                    mdl = OneClassSVM(kernel="rbf", nu=0.5, gamma="scale")
                elif name == "iforest":
                    mdl = IsolationForest(n_estimators=200, max_samples="auto", contamination=0.1, random_state=seed)

                y_pred, y_scores, t_rec, _ = fit_predict_model(name, mdl, X_tr, y_tr, X_te, setup, scaler, seed, artifacts_dir)
                met = _metric_dict(y_te, y_pred, y_scores)
                rows.append({"setup":setup,"seed":seed,"fold":fold,"model":name, **met, **asdict(t_rec)})

                for a in np.unique(atk_te):
                    mask = (atk_te == a)
                    if mask.sum() == 0: continue
                    m_atk = _metric_dict(y_te[mask], y_pred[mask], None)
                    per_attack_rows.append({"setup":setup,"seed":seed,"fold":fold,"model":name,"attack_type":a, **m_atk})

    df = pd.DataFrame(rows)
    df.to_csv(results_dir / f"cv_results_{setup}.csv", index=False)
    pd.DataFrame(per_attack_rows).to_csv(results_dir / f"per_attack_results_{setup}.csv", index=False)
    return df

def summarize_df(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty: return df
    grp = df.groupby(["setup","model"]).agg(
        accuracy_mean=("accuracy","mean"), accuracy_std=("accuracy","std"),
        precision_mean=("precision","mean"), precision_std=("precision","std"),
        recall_mean=("recall","mean"), recall_std=("recall","std"),
        f1_mean=("f1","mean"), f1_std=("f1","std"),
        roc_auc_mean=("roc_auc","mean"), roc_auc_std=("roc_auc","std"),
        pr_auc_mean=("pr_auc","mean"), pr_auc_std=("pr_auc","std"),
        t_prep_mean=("t_preprocess","mean"),
        t_fit_mean=("t_fit","mean"),
        t_pred_mean=("t_predict","mean"),
        mem_peak_mb_mean=("mem_peak_mb","mean"),
        model_size_mb_mean=("model_size_mb","mean"),
        n=("f1","count"),
    ).reset_index()

    def ci95(mean, std, n):
        if n and n > 1 and pd.notna(std):
            half = float(t_dist.ppf(0.975, df=n-1)) * (std / math.sqrt(n))
            return half
        return np.nan

    grp["f1_ci95"] = [ci95(m, s, n) for m, s, n in zip(grp["f1_mean"], grp["f1_std"], grp["n"])]
    return grp

def significance_tests(df_bal: pd.DataFrame, df_imbal: pd.DataFrame, out_csv: Path):
    rows = []
    models = sorted(set(df_bal.get("model", pd.Series()).unique()).union(set(df_imbal.get("model", pd.Series()).unique())))
    for m in models:
        fb = df_bal[df_bal["model"]==m]["f1"].values if not df_bal.empty else np.array([])
        fi = df_imbal[df_imbal["model"]==m]["f1"].values if not df_imbal.empty else np.array([])
        n = min(len(fb), len(fi))
        if n > 5:
            try: _, t_p = ttest_rel(fb[:n], fi[:n], nan_policy="omit")
            except Exception: t_p = np.nan
            try: _, w_p = wilcoxon(fb[:n], fi[:n])
            except Exception: w_p = np.nan
            rows.append({"model":m,"paired_t_pvalue":t_p,"wilcoxon_pvalue":w_p,"pairs_n":n})
    pd.DataFrame(rows).to_csv(out_csv, index=False)

def sensitivity_grids(X, y, out_dir: Path, seeds: List[int]):
    out = out_dir / "sensitivity"; out.mkdir(parents=True, exist_ok=True)
    grids = {
        "rf": {"n_estimators":[100,200,400], "max_depth":[5,10,None]},
        "gb": {"n_estimators":[100,150], "learning_rate":[0.05,0.1], "max_depth":[2,3]},
        "knn": {"n_neighbors":[3,5,11,21], "weights":["uniform","distance"]},
        "logreg":{"C":[0.1,1.0,10.0], "class_weight":[None,"balanced"]},
        "ocsvm":{"nu":[0.1,0.5,0.9], "gamma":["scale","auto"]},
        "iforest":{"n_estimators":[100,200,400], "contamination":[0.01,0.05,0.1,0.2]},
    }
    for model_name, grid in grids.items():
        rows = []
        for params in ParameterGrid(grid):
            f1s = []
            for seed in seeds:
                n_splits = _auto_n_splits(y, 5)
                skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
                for tr_idx, te_idx in skf.split(X, y):
                    X_tr, X_te = X.iloc[tr_idx], X.iloc[te_idx]
                    y_tr, y_te = y.iloc[tr_idx], y.iloc[te_idx]
                    scaler = StandardScaler()
                    X_tr = scaler.fit_transform(X_tr); X_te = scaler.transform(X_te)

                    if model_name == "rf":
                        mdl = RandomForestClassifier(random_state=seed, **params)
                        mdl.fit(X_tr, y_tr); y_pred = mdl.predict(X_te)
                    elif model_name == "gb":
                        mdl = GradientBoostingClassifier(random_state=seed, **params)
                        mdl.fit(X_tr, y_tr); y_pred = mdl.predict(X_te)
                    elif model_name == "knn":
                        k = min(params["n_neighbors"], max(1, X_tr.shape[0]))
                        mdl = KNeighborsClassifier(n_neighbors=k, weights=params["weights"])
                        mdl.fit(X_tr, y_tr); y_pred = mdl.predict(X_te)
                    elif model_name == "logreg":
                        mdl = LogisticRegression(max_iter=300, random_state=seed, **params)
                        mdl.fit(X_tr, y_tr); y_pred = mdl.predict(X_te)
                    elif model_name == "ocsvm":
                        mdl = OneClassSVM(**params)
                        mdl.fit(X_tr); y_pred = (mdl.predict(X_te) == -1).astype(int)
                    elif model_name == "iforest":
                        mdl = IsolationForest(random_state=seed, **params)
                        mdl.fit(X_tr); y_pred = (mdl.predict(X_te) == -1).astype(int)
                    f1s.append(f1_score(y_te, y_pred, zero_division=0))
            rows.append({"model":model_name, **params, "f1_mean":float(np.mean(f1s)), "f1_std":float(np.std(f1s)), "n":len(f1s)})
        pd.DataFrame(rows).to_csv(out / f"sensitivity_{model_name}.csv", index=False)

def unsupervised_threshold_sweep(X, y, out_dir: Path, seeds: List[int]):
    out = out_dir / "unsup_tuning"; out.mkdir(parents=True, exist_ok=True)
    rows = []
    for model_name in ["ocsvm", "iforest"]:
        for seed in seeds:
            n_splits = _auto_n_splits(y, 5)
            skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
            for tr_idx, te_idx in skf.split(X, y):
                X_tr, X_te = X.iloc[tr_idx], X.iloc[te_idx]
                y_tr, y_te = y.iloc[tr_idx], y.iloc[te_idx]
                scaler = StandardScaler()
                X_tr = scaler.fit_transform(X_tr); X_te = scaler.transform(X_te)
                if model_name == "ocsvm":
                    mdl = OneClassSVM(kernel="rbf", nu=0.5, gamma="scale"); mdl.fit(X_tr)
                    scores = mdl.decision_function(X_te); anomaly = -scores
                else:
                    mdl = IsolationForest(n_estimators=200, max_samples="auto", contamination=0.1, random_state=seed); mdl.fit(X_tr)
                    scores = mdl.decision_function(X_te); anomaly = -scores
                for q in [50,60,70,80,90,95,97,99]:
                    thr = np.percentile(anomaly, q)
                    y_pred = (anomaly >= thr).astype(int)
                    rows.append({"model":model_name,"seed":seed,"q":q, **_metric_dict(y_te, y_pred, None)})
    pd.DataFrame(rows).to_csv(out / "unsupervised_threshold_sweep.csv", index=False)

def plot_bar(means: pd.DataFrame, metric_col: str, title: str, fname: Path):
    if means.empty: return
    plt.figure(figsize=(9,5))
    order = means.sort_values(f"{metric_col}_mean", ascending=False)
    x = np.arange(len(order))
    plt.bar(x, order[f"{metric_col}_mean"].values, yerr=order[f"{metric_col}_std"].values, capsize=4)
    plt.xticks(x, order["model"].values, rotation=25, ha="right")
    plt.ylabel(metric_col); plt.title(title); plt.tight_layout()
    plt.savefig(fname, dpi=200); plt.close()

def run_for_dataset(path: Path, out_dir: Path, sampler: str, seeds: List[int],
                    do_sensitivity: bool, do_unsup_sweep: bool, do_plots: bool) -> Dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "artifacts").mkdir(parents=True, exist_ok=True)

    t0 = time.perf_counter()
    df_raw = parse_blockchain_logs(path)
    X, y, atk = build_feature_label(df_raw)
    t_feat = time.perf_counter() - t0

    pd.DataFrame([{"t_feature_extract": t_feat, "n_rows": len(X), "n_cols": X.shape[1]}]).to_csv(out_dir / "feature_extract_timing.csv", index=False)

    df_imbal = crossval_with_per_attack(X, y, atk, setup="imbalanced", seeds=seeds, sampler="none", results_dir=out_dir)
    df_bal   = crossval_with_per_attack(X, y, atk, setup="balanced",   seeds=seeds, sampler=("none" if sampler=="none" else sampler), results_dir=out_dir)

    sum_imbal = summarize_df(df_imbal); sum_bal = summarize_df(df_bal)
    if not sum_imbal.empty: sum_imbal.to_csv(out_dir / "summary_metrics_imbalanced.csv", index=False)
    if not sum_bal.empty:   sum_bal.to_csv(out_dir / "summary_metrics_balanced.csv", index=False)

    if do_plots:
        if not sum_imbal.empty: plot_bar(sum_imbal.rename(columns={"setup":"_"}), "f1", "F1 by Model (Imbalanced)", out_dir / "bar_f1_imbalanced.png")
        if not sum_bal.empty:   plot_bar(sum_bal.rename(columns={"setup":"_"}), "f1", "F1 by Model (Balanced)",   out_dir / "bar_f1_balanced.png")

    if do_sensitivity: sensitivity_grids(X, y, out_dir, seeds=seeds)
    if do_unsup_sweep: unsupervised_threshold_sweep(X, y, out_dir, seeds=seeds)

    return {
        "sum_imbal": out_dir / "summary_metrics_imbalanced.csv",
        "sum_bal":   out_dir / "summary_metrics_balanced.csv",
        "cv_imbal":  out_dir / "cv_results_imbalanced.csv",
        "cv_bal":    out_dir / "cv_results_balanced.csv",
    }

def cross_dataset_summary(sumA: Path, sumB: Path, out_path: Path, nameA="DatasetA", nameB="DatasetB"):
    frames = []
    if sumA.exists(): 
        dfA = pd.read_csv(sumA); dfA["dataset"] = nameA; frames.append(dfA)
    if sumB and Path(sumB).exists():
        dfB = pd.read_csv(sumB); dfB["dataset"] = nameB; frames.append(dfB)
    if frames:
        both = pd.concat(frames, ignore_index=True)
        both.to_csv(out_path, index=False)
        return both
    return pd.DataFrame()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataA", type=str, required=True, help="Path to dataset A log file")
    ap.add_argument("--dataB", type=str, default="", help="Optional dataset B log file for cross-dataset validation")
    ap.add_argument("--outdir", type=str, default="./results", help="Output base directory")
    ap.add_argument("--sampler", type=str, default=("smote" if HAS_IMB else "none"), choices=["none","smote","adasyn"], help="Resampling for balanced run")
    ap.add_argument("--seeds", type=int, nargs="+", default=[0,1,2,3,4], help="Random seeds for CV")
    ap.add_argument("--no_sensitivity", action="store_true")
    ap.add_argument("--no_unsup_sweep", action="store_true")
    ap.add_argument("--no_plots", action="store_true")
    ap.add_argument("--no_significance", action="store_true")
    args = ap.parse_args()

    base = Path(args.outdir); ensure_dirs(base)
    meta = {
        "args": vars(args),
        "versions": version_meta(),
        "has_imblearn": HAS_IMB,
        "has_torch": HAS_TORCH,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    save_json(meta, base / "run_metadata.json")

    A_dir = base / "datasetA"
    resA = run_for_dataset(Path(args.dataA), A_dir, sampler=args.sampler, seeds=args.seeds,
                           do_sensitivity=not args.no_sensitivity,
                           do_unsup_sweep=not args.no_unsup_sweep,
                           do_plots=not args.no_plots)

    both_bal = both_imbal = pd.DataFrame()
    if args.dataB:
        B_dir = base / "datasetB"
        resB = run_for_dataset(Path(args.dataB), B_dir, sampler=args.sampler, seeds=args.seeds,
                               do_sensitivity=not args.no_sensitivity,
                               do_unsup_sweep=not args.no_unsup_sweep,
                               do_plots=not args.no_plots)

        
        cross_dataset_summary(A_dir/"summary_metrics_imbalanced.csv", B_dir/"summary_metrics_imbalanced.csv", base/"cross_dataset_summary_imbalanced.csv", "DatasetA","DatasetB")
        cross_dataset_summary(A_dir/"summary_metrics_balanced.csv",   B_dir/"summary_metrics_balanced.csv",   base/"cross_dataset_summary_balanced.csv",   "DatasetA","DatasetB")

       if not args.no_significance:
        try:
            df_bal_A   = pd.read_csv(A_dir/"cv_results_balanced.csv")
            df_imbal_A = pd.read_csv(A_dir/"cv_results_imbalanced.csv")
            significance_tests(df_bal_A, df_imbal_A, base/"significance_tests_datasetA.csv")
            if args.dataB:
                df_bal_B   = pd.read_csv((base/"datasetB"/"cv_results_balanced.csv"))
                df_imbal_B = pd.read_csv((base/"datasetB"/"cv_results_imbalanced.csv"))
                significance_tests(df_bal_B, df_imbal_B, base/"significance_tests_datasetB.csv")
        except Exception as e:
            print("[WARN] significance tests skipped:", e)

    print(f"[INFO] Done. Outputs under: {base.resolve()}")

if __name__ == "__main__":
    main()
